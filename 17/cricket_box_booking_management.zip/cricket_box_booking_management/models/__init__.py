from . import account_move
from . import cricket_box
from . import cricket_box_registration
from . import time_slots
